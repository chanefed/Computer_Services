﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TESTINGtheSearching
{
    public class MyComputerObj
    {        
        public MyComputerObj() { }

        public string NSCCEquipmentNumber { get; set; }

        public string Make { get; set; }

        public string Model { get; set; }

        public string SerialNumber { get; set; }

        public string PONumber { get; set; }

        public string PurchaseDate { get; set; }

        public int WarrantyDate { get; set; }

        public int LocationID { get; set; }

        public string Campus { get; set; }

        public string Building { get; set; }

        public string Room { get; set; }

    }
}
