﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TESTINGtheSearching
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            string[] CompSearchOpts = { "Select a search option ...", "NSCC Serial No.", "Computer Serial No.", "P.O. No.", "Purchase Date - YYYY-MM-DD", "Warranty Start Date - YYYY-MM-DD", "Make - Dell ( type \"all\" )", "Dell - (Specify Model)", "Make - HP ( type \"all\" )", "HP - (Specify Model)" };

            foreach (string option in CompSearchOpts)
            {
                cboSearchOptions.Items.Add(option);
            }

            cboSearchOptions.SelectedIndex = 0;
        }


    public void GetInput(string LookingFor,int thatNum)
        {
            DataSet resultsDataSet = MyComputerDB.GetComputer(LookingFor,thatNum);
            
            dataGridView1.ReadOnly = true;
            dataGridView1.DataSource = resultsDataSet.Tables[0];
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string yoSearch = txtSearchInput.Text;
            int numSelected = cboSearchOptions.SelectedIndex;
            if (numSelected <= 0)
            {
                MessageBox.Show("You must select a search option first.");
            }
            else
            {
                //MessageBox.Show(cboSearchOptions.SelectedIndex.ToString()); was for checking selected index
                GetInput(yoSearch,numSelected);
            }
        }
    }
}
