﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TESTINGtheSearching
{
    class MyComputerDB
    {
        public static DataSet GetComputer(string computerID,int yoSelection)
        {
            SqlConnection connection = SimpleServerConnectDB.GetConnection();
            string selectStatement = "";
            switch (yoSelection)
            {
                case 1:
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [NSCCEquipmentNumber] = " + "'" + computerID + "'"
                        + " ORDER BY Campus, Building, Room";
                    break;
                case 2:
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [SerialNumber] = " + "'" + computerID + "'"
                        + " ORDER BY Campus, Building, Room";
                    break;
                case 3:
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [PONumber] = " + "'" + computerID + "'"
                        + " ORDER BY Campus, Building, Room";
                    break;
                case 4:

                    DateTime yoDate = Convert.ToDateTime(computerID);
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [PurchaseDate] = " + "'" + yoDate + "'"
                        + " ORDER BY Campus, Building, Room";
                    break;
                case 5:

                    DateTime moDate = Convert.ToDateTime(computerID);
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [WarrantyDate] = " + "'" + moDate + "'"
                        + " ORDER BY Campus, Building, Room";
                    break;
                case 6:
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [Make] = " + "'" + "Dell" + "'" + " AND "  +"'" + computerID + "'" +  " = " + "'" + "all" +"'"
                        + " ORDER BY Campus, Building, Room";
                    break;
                case 7:
                    selectStatement = " SELECT NSCCEquipmentNumber, Make, Model, SerialNumber, PONumber, PurchaseDate, WarrantyDate, Campus, Building, Room"
                        + " FROM Computer "
                        + " INNER JOIN LocationTable ON Computer.LocationID = LocationTable.LocationID "
                        + " WHERE [Make] = " + "'" + "Dell" + "'" + " AND [Model] = "  + "'" + computerID + "'"
                        + " ORDER BY Campus, Building, Room";
                    break;
            }


            var dataAdapter = new SqlDataAdapter(selectStatement, connection);

            var commandBuilder = new SqlCommandBuilder(dataAdapter);

            var yoDataSet = new DataSet();

            dataAdapter.Fill(yoDataSet);

            return yoDataSet;

            //SqlCommand selectCommand = new SqlCommand(selectStatement, connection);//creating a sqlcommand with a connection and a select statement passed on.

            //var select = "SELECT * FROM tblEmployee";
            //var c = new SqlConnection(yourConnectionString); // Your Connection String here


            //dataAdapter.Fill(yoDataSet);
            //dataGridView1.ReadOnly = true;
            //dataGridView1.DataSource = yoDataSet.Tables[0];

            //try
            //{
            //    connection.Open();
            //    SqlDataReader custReader = selectCommand.ExecuteReader(CommandBehavior.SingleRow);

            //    if (custReader.Read())
            //    {
            //        MyComputerObj computer = new MyComputerObj();

            //        computer.NSCCEquipmentNumber = (int) custReader["NSCCEquipmentNumber"];
            //        computer.Make = custReader["Make"].ToString();
            //        computer.Model = custReader["Model"].ToString();
            //        computer.SerialNumber = custReader["SerialNumber"].ToString();
            //        computer.PONumber = custReader["PONumber"].ToString();
            //        computer.PurchaseDate = custReader["PurchaseDate"].ToString();
            //        computer.WarrantyDate = (int) custReader["WarrantyDate"];
            //        computer.LocationID = (int)custReader["LocationID"];
            //        computer.Campus = custReader["Campus"].ToString();
            //        computer.Building = custReader["Building"].ToString();
            //        computer.Room = custReader["Room"].ToString();
            //        return computer;
            //    }
            //    else
            //    {
            //        return null;
            //    }
            //}
            //catch (SqlException ex)
            //{
            //    throw ex;
            //}
            //finally
            //{
            //    connection.Close();
            //}
        }
    }
}
