﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace TESTINGtheSearching
{
    public static class SimpleServerConnectDB
    {
        public static SqlConnection GetConnection()
        {
            string connectionString =
                "Data Source={SQL Server};SERVER=Nsccsqlinst16.nscc.edu;Database=CITC_CTEAM;MultipleActiveResultSets=true;UID=CITC_CTEAM;PWD=ITROCKS;";
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }
    }



    public static class MMABooksDB
    {

    }

}
